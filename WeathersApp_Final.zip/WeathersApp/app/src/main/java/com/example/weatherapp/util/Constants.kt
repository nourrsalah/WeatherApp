package com.example.weatherapp.util

class Constants {

    companion object{

        const val API_KEY = "a2e2bc2255224821923103229240508"
        const val BASE_URL = "https://api.weatherapi.com/v1/"
        const val SEARCH_TIME_DELAY = 500L
        const val QUERY_PAGE_SIZE = 20
    }
}