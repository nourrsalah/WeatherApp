package com.example.weatherapp.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.adapters.SavedAdapter
import com.example.weatherapp.ui.WeatherActivity
import com.example.weatherapp.ui.WeatherViewModel
import com.example.weathersapp.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar

class SavedFragment : Fragment() {
    lateinit var viewModel: WeatherViewModel
    private lateinit var savedAdapter: SavedAdapter
    private lateinit var rvSaved: RecyclerView
    private lateinit var tvDate: TextView
    private val args: SavedFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_saved, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = (activity as WeatherActivity).viewModel
        rvSaved = view.findViewById(R.id.rvSaved)
        tvDate = view.findViewById(R.id.textView6)


        val floatingActionButton = view.findViewById<FloatingActionButton>(R.id.floatingActionButton)
        floatingActionButton.setOnClickListener {
//            forecastday?.let {
//                viewModel.saveArticle(it)
//                Snackbar.make(view, "Article saved successfully", Snackbar.LENGTH_SHORT).show()
//            } ?: run {
                Snackbar.make(view, "No forecast data available", Snackbar.LENGTH_SHORT).show()
            val bottomSheetFragment = HalfScreenFragment()
            bottomSheetFragment.show(parentFragmentManager, bottomSheetFragment.tag)
        }

        setupRecyclerView()

        viewModel.savedCities.observe(viewLifecycleOwner) { savedCities ->
            savedAdapter.submitList(savedCities)
        }
    }




    private fun setupRecyclerView() {
        savedAdapter = SavedAdapter { weatherResponse ->
            val bundle = Bundle().apply {
                putString("cityName", weatherResponse.location.name)
            }
            findNavController().navigate(R.id.redirectFragment,bundle)

        }
        rvSaved.apply {
            adapter = savedAdapter
            layoutManager = LinearLayoutManager(activity)
        }
    }
}

