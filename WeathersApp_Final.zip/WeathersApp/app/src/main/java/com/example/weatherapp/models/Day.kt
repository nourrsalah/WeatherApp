package com.example.weatherapp.models

data class Day (
    var avgtemp_c: Double,
    var condition: Condition
)