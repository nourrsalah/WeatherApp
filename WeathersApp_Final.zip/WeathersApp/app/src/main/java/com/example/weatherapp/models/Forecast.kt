package com.example.weatherapp.models

data class Forecast(
    var forecastday: List<Forecastday>
)
