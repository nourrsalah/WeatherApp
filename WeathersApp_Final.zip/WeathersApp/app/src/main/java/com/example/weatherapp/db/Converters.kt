package com.example.weatherapp

import androidx.room.TypeConverter
import com.example.weatherapp.models.Condition
import com.example.weatherapp.models.Day
import com.example.weatherapp.models.Hour
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Converters {
    @TypeConverter
    fun fromHourList(value: List<Hour>): String {
        val gson = Gson()
        val type = object : TypeToken<List<Hour>>() {}.type
        return gson.toJson(value, type)
    }

    @TypeConverter
    fun toHourList(value: String): List<Hour> {
        val gson = Gson()
        val type = object : TypeToken<List<Hour>>() {}.type
        return gson.fromJson(value, type)
    }

    @TypeConverter
    fun fromDay(day: Day): String {
        return Gson().toJson(day)
    }

    @TypeConverter
    fun toDay(dayString: String): Day {
        return Gson().fromJson(dayString, Day::class.java)
    }
}
