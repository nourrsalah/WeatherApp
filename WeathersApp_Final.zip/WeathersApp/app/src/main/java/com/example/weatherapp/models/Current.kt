package com.example.weatherapp.models

data class Current(
    val condition: Condition,
    val humidity: Int,
    val is_day: Int,
    val precip_in: Int,
    val precip_mm: Int,
    val temp_c: Double,
    val wind_kph: Double,
)