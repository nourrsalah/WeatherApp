package com.example.weatherapp

import android.app.Application

class WeatherApp : Application()