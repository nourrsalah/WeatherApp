package com.example.weatherapp.ui

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.example.weatherapp.util.Resource
import com.example.weatherapp.models.Forecastday
import com.example.weatherapp.models.Location
import com.example.weatherapp.models.WeatherResponse
import com.example.weatherapp.repository.WeatherRepository
import kotlinx.coroutines.launch
import retrofit2.Response
import java.io.IOException

class WeatherViewModel(
    val app: Application,
    private val weatherRepository: WeatherRepository
) : AndroidViewModel(app) {

    val searchWeather: MutableLiveData<Resource<List<Location>>> = MutableLiveData()

    private val _weatherForecast = MutableLiveData<Resource<WeatherResponse>>()
    val weatherForecast: LiveData<Resource<WeatherResponse>> get() = _weatherForecast

    private val _savedCities = MutableLiveData<List<WeatherResponse>>()
    val savedCities: LiveData<List<WeatherResponse>> get() = _savedCities

    private val savedCitiesList = mutableListOf<WeatherResponse>()

    fun saveArticle(forecastday: Forecastday) = viewModelScope.launch {
        weatherRepository.upsert(forecastday)
    }

    fun getSavedNews() = weatherRepository.getSavedNews()

    fun deleteArticle(forecastday: Forecastday) = viewModelScope.launch {
        weatherRepository.deleteArticle(forecastday)
    }

    fun searchCities(query: String) {
        viewModelScope.launch {
            safeSearchCitiesCall(query)
        }
    }

    fun fetchForecast(location: String, days: Int) {
        getWeatherForecast(location, days)
    }

    fun displayWeatherData(): LiveData<Resource<WeatherResponse>> {
        return weatherForecast
    }
    fun saveCity(location: Location) {
        viewModelScope.launch {
            if (hasInternetConnection(app.applicationContext)) {
                val response =
                    weatherRepository.getForecast(location.name, 1) // Assuming 1 day for now
                val weatherResponse = handleWeatherForecastResponse(response)
                if (weatherResponse is Resource.Success) {
                    savedCitiesList.add(weatherResponse.data!!)
                    _savedCities.postValue(savedCitiesList)
                }
            } else {
                _savedCities.postValue(savedCitiesList)
            }
        }
    }

    private val _locationResult = MutableLiveData<Resource<Location>>()
    val locationResult: LiveData<Resource<Location>> get() = _locationResult


    fun getLocation(lat: Double, lon: Double, apiKey: String): LiveData<Resource<Location>> {
        val locationResult = MutableLiveData<Resource<Location>>()

        viewModelScope.launch {
            locationResult.postValue(Resource.Loading())
            try {
                if (hasInternetConnection(app.applicationContext)) {
                    val response = weatherRepository.getLocation(lat, lon, apiKey)
                    locationResult.postValue(handleLocationResponse(response))
                } else {
                    locationResult.postValue(Resource.Error("No internet connection"))
                }
            } catch (e: Exception) {
                locationResult.postValue(Resource.Error(e.message ?: "Unknown error"))
            }
        }

        return locationResult
    }

    private fun handleLocationResponse(response: Response<Location>): Resource<Location> {
        return if (response.isSuccessful) {
            response.body()?.let { Resource.Success(it) } ?: Resource.Error("No data")
        } else {
            Resource.Error(response.message())
        }
    }

    fun getWeatherForecast(location: String, days: Int) {
        _weatherForecast.postValue(Resource.Loading())

        viewModelScope.launch {
            try {
                if (hasInternetConnection(app.applicationContext)) {
                    val response = weatherRepository.getForecast(location, days)
                    _weatherForecast.postValue(handleWeatherForecastResponse(response))
                } else {
                    _weatherForecast.postValue(Resource.Error("No internet connection"))
                }
            } catch (e: Exception) {
                _weatherForecast.postValue(Resource.Error(e.message ?: "Unknown error"))
            }
        }
    }


    private fun hasInternetConnection(context: Context): Boolean {
        val connectivityManager = context.getSystemService(
            Context.CONNECTIVITY_SERVICE
        ) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val activeNetwork = connectivityManager.activeNetwork ?: return false
            val capabilities =
                connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
            return when {
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        } else {
            connectivityManager.activeNetworkInfo?.run {
                return when (type) {
                    ConnectivityManager.TYPE_WIFI -> true
                    ConnectivityManager.TYPE_MOBILE -> true
                    ConnectivityManager.TYPE_ETHERNET -> true
                    else -> false
                }
            }
        }
        return false
    }

    private fun handleWeatherForecastResponse(response: Response<WeatherResponse>): Resource<WeatherResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        return Resource.Error(response.message())
    }
    

    private fun handleSearchCitiesResponse(response: Response<List<Location>>): Resource<List<Location>> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                return Resource.Success(resultResponse)
            }
        }
        return Resource.Error(response.message())
    }

    private suspend fun safeSearchCitiesCall(query: String) {
        searchWeather.postValue(Resource.Loading())
        try {
            if (hasInternetConnection(app.applicationContext)) {
                val response = weatherRepository.searchCities(query)
                searchWeather.postValue(handleSearchCitiesResponse(response))
            } else {
                searchWeather.postValue(Resource.Error("No internet connection"))
            }
        } catch (t: Throwable) {
            when (t) {
                is IOException -> searchWeather.postValue(Resource.Error(t.message ?: ""))
                else -> searchWeather.postValue(Resource.Error(t.message ?: ""))
            }
        }
    }
}
