package com.example.weatherapp.ui.fragments

import android.Manifest
import android.content.Context
import android.content.IntentSender
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.weatherapp.adapters.DaysAdapter
import com.example.weatherapp.adapters.HoursAdapter
import com.example.weatherapp.api.RetrofitInstance
import com.example.weatherapp.api.WeatherApi
import com.example.weatherapp.models.Hour
import com.example.weatherapp.models.Location
import com.example.weatherapp.models.WeatherResponse
import com.example.weatherapp.ui.WeatherActivity
import com.example.weatherapp.ui.WeatherViewModel
import com.example.weatherapp.util.Constants.Companion.API_KEY
import com.example.weatherapp.util.Resource
import com.example.weathersapp.R
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*

class HomeFragment : Fragment() {

    lateinit var viewModel: WeatherViewModel
    private lateinit var hoursAdapter: HoursAdapter
    private lateinit var daysAdapter: DaysAdapter
    private lateinit var locationRequest: LocationRequest
    private lateinit var date: TextView
    private lateinit var saved: ImageView
    private lateinit var tvDegree: TextView
    private lateinit var tvCity: TextView
    private lateinit var tvWindNumber: TextView
    private lateinit var tvHumidNumber: TextView
    private lateinit var ivWeather: ImageView
    private lateinit var rvHours: RecyclerView
    private lateinit var rvDays: RecyclerView
    private lateinit var paginationProgressBar: ProgressBar

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvHours = view.findViewById(R.id.rvHours)
        rvDays = view.findViewById(R.id.rvDays)
        viewModel = (activity as WeatherActivity).viewModel
        date = view.findViewById(R.id.tvData)
        saved = view.findViewById(R.id.imageView)
        tvCity = view.findViewById(R.id.tvCityName)
        tvDegree = view.findViewById(R.id.tvDegree)
        tvWindNumber = view.findViewById(R.id.tvWindNumber)
        tvHumidNumber = view.findViewById(R.id.tvHumidNumber)
        ivWeather = view.findViewById(R.id.ivWeather)
        paginationProgressBar = view.findViewById(R.id.paginationProgressBar)

        // Initialize adapters and RecyclerViews
        setupRecyclerView()
        setupRecyclerView2()

        locationRequest = LocationRequest.create().apply {
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
            interval = 5000
            fastestInterval = 2000
        }

        saved.setOnClickListener {
            findNavController().navigate(R.id.savedFragment)
//            val fragmentManager = parentFragmentManager
//            val transaction = fragmentManager.beginTransaction()
//            transaction.replace(R.id.weatherNavFragment, SavedFragment())
//            transaction.addToBackStack(null)
//            transaction.commit()
        }

        handleAppLaunch()
        setupObservers()

    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun handleAppLaunch() {
        val sharedPreferences = requireContext().getSharedPreferences("MySharedPrefs", Context.MODE_PRIVATE)
        val lastCity = sharedPreferences.getString("city_name", null)

        if (isNetworkAvailable(requireContext())) {
            if (isGPSEnabled()) {
                // GPS is enabled, fetch new weather data
                if (lastCity == null) {
                    getCurrentLocation()
                } else {
                    fetchWeatherData(lastCity)
                }
            } else {
                // GPS is not enabled, show a banner or message
                showLocationDisabledBanner()
            }
        } else {
            // Wi-Fi is off, check shared preferences for saved city
            if (lastCity != null) {
                // Display saved city weather data
                fetchWeatherData(lastCity)
            } else {
                Toast.makeText(requireContext(), "No network connection and no city saved", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun getCurrentLocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            if (isGPSEnabled()) {
                requestLocationUpdates()
            } else {
                turnOnGPS()
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    private fun isGPSEnabled(): Boolean {
        val locationManager = requireContext().getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
    }

    private fun requestLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        LocationServices.getFusedLocationProviderClient(requireContext())
            .requestLocationUpdates(locationRequest, object : LocationCallback() {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onLocationResult(locationResult: LocationResult) {
                    super.onLocationResult(locationResult)
                    LocationServices.getFusedLocationProviderClient(requireContext())
                        .removeLocationUpdates(this)
                    if (locationResult.locations.isNotEmpty()) {
                        val lastLocation = locationResult.locations.last()
                        val latitude = lastLocation.latitude
                        val longitude = lastLocation.longitude

                        getCityName(latitude, longitude)
                    }
                }
            }, Looper.getMainLooper())
    }
    @RequiresApi(Build.VERSION_CODES.O)
    private fun getCityName(lat: Double, lon: Double) {
        viewModel.getLocation(lat, lon, API_KEY).observe(viewLifecycleOwner) { result ->
            when (result) {
                is Resource.Success<*> -> {
                    val location = result.data
                    val cityName = location?.name ?: "Unknown city"
                    Log.d("HomeFragment", "City Name: $cityName")
                    tvCity.text = cityName
                    Log.d("HomeFragment", "tvCity text set to: ${tvCity.text}")
                    saveCityInPreferences(cityName)
                    fetchWeatherData(cityName)
                }
                is Resource.Error<*> -> {
                    Log.e("HomeFragment", "API call failed: ${result.message}")
                    handleFailure()
                }
                is Resource.Loading<*> -> {
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun handleFailure() {
        tvCity.text = "Unknown city"
        Log.d("HomeFragment", "tvCity text set to: ${tvCity.text}")
        saveCityInPreferences("Unknown city")
        fetchWeatherData("Unknown city")
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun fetchWeatherData(cityName: String) {
        viewModel.getWeatherForecast(cityName,5)
    }

    private fun setupObservers() {
        viewModel.weatherForecast.observe(this.viewLifecycleOwner) { resource ->
            when (resource) {
                is Resource.Loading -> {
                    //el loading indicator
                    showProgressBar()
                }
                is Resource.Success -> {
                    hideProgressBar()
                    val weatherResponse = resource.data
                    if (weatherResponse != null) {
                        val next24Hours = weatherResponse.forecast.forecastday.flatMap { it.hour }
                        hoursAdapter.submitList(next24Hours)
                        daysAdapter.setData(weatherResponse.forecast.forecastday)

                        tvCity.text = weatherResponse.location.name
                        tvDegree.text = "${weatherResponse.current.temp_c}°C"
                        tvWindNumber.text = "${weatherResponse.current.wind_kph} km/h"
                        tvHumidNumber.text = "${weatherResponse.current.humidity}%"
                        Glide.with(requireContext()).load("https:${weatherResponse.current.condition.icon}").into(ivWeather)
                    } else {
                        Toast.makeText(requireContext(), "No weather data found", Toast.LENGTH_SHORT).show()
                    }
                }
                is Resource.Error -> {
                    Toast.makeText(requireContext(), "Error: ${resource.message}", Toast.LENGTH_SHORT).show()
                    hideProgressBar()
                }
            }
        }
    }


    private fun saveCityInPreferences(cityName: String) {
        val sharedPreferences = requireContext().getSharedPreferences("MySharedPrefs", Context.MODE_PRIVATE)
        with(sharedPreferences.edit()) {
            putString("city_name", cityName)
            apply()
        }
    }

    private fun showLocationDisabledBanner() {
        Toast.makeText(requireContext(), "Location services are disabled. Please enable location services to get updated weather information.", Toast.LENGTH_LONG).show()
    }

    private fun turnOnGPS() {
        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)

        val client = LocationServices.getSettingsClient(requireContext())
        val task = client.checkLocationSettings(builder.build())

        task.addOnSuccessListener {
            requestLocationUpdates()
        }

        task.addOnFailureListener { e ->
            if (e is ResolvableApiException) {
                try {
                    e.startResolutionForResult(requireActivity(), 0x1)
                } catch (sendEx: IntentSender.SendIntentException) {
                }
            }
        }
    }

    private fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
        return networkCapabilities != null &&
                (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))
    }

    private fun setupRecyclerView() {
        hoursAdapter = HoursAdapter {
        }
        rvHours.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        rvHours.adapter = hoursAdapter
    }

    private fun setupRecyclerView2() {
        daysAdapter = DaysAdapter {
        }
        rvDays.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        rvDays.adapter = daysAdapter
    }

    private fun showProgressBar() {
        paginationProgressBar.visibility = View.VISIBLE
    }

    private fun hideProgressBar() {
        paginationProgressBar.visibility = View.GONE
    }
}
