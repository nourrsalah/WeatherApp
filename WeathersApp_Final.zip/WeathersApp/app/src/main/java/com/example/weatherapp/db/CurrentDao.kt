package com.example.weatherapp.db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.weatherapp.models.Forecastday

@Dao
interface CurrentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(forecast: Forecastday) : Long

    @Query("SELECT * FROM weather")
    fun getAll(): LiveData<List<Forecastday>>

    @Query("SELECT * FROM weather")
    suspend fun getAllForecastsList(): List<Forecastday>

    @Delete
    suspend fun deleteCurrent(forecast: Forecastday)
}