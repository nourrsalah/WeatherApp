package com.example.weatherapp.repository

import com.example.weatherapp.api.RetrofitInstance.Companion.api
import com.example.weatherapp.api.WeatherApi
import com.example.weatherapp.db.CurrentDatabase
import com.example.weatherapp.models.Forecastday
import com.example.weatherapp.models.Location
import com.example.weatherapp.models.WeatherResponse
import com.example.weatherapp.util.Constants.Companion.API_KEY
import retrofit2.Call
import retrofit2.Response

class WeatherRepository(
    private val db: CurrentDatabase,
    private val weatherApi: WeatherApi
) {

    suspend fun searchCities(location: String) =
        weatherApi.searchCities(API_KEY, location)


    suspend fun getForecast(location: String, days: Int) =
        weatherApi.getForecast(API_KEY, location, days)


    suspend fun upsert(forecastday: Forecastday) = db.getCurrentDao().upsert(forecastday)


    fun getSavedNews() = db.getCurrentDao().getAll()


    suspend fun deleteArticle(forecastday: Forecastday) = db.getCurrentDao().deleteCurrent(forecastday)


    suspend fun getLocation(lat: Double, lon: Double, apiKey: String): Response<Location> {
        return weatherApi.getLocation(lat, lon, apiKey)
    }

}
