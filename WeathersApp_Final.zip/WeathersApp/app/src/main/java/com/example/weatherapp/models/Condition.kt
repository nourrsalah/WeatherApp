package com.example.weatherapp.models

data class Condition(
    val code: String,
    val icon: String,
    val text: String
)